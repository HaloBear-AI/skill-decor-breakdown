"""Validate the scene record and derive one shared set of board labels."""

import json
import re
from pathlib import Path
from tempfile import NamedTemporaryFile

ROOT = Path(__file__).resolve().parents[1]
AVAILABLE = {"visible", "partial"}
STATUSES = AVAILABLE | {"not_visible", "absent"}
DEFAULT_SIZE = "1536x2048"
OVERLAY_CUE = "整张生成图必须没有任何文字、数字、字母、伪字形、水印、引线或网格线。"


class BoardError(Exception):
    def __init__(self, message: str, exit_code: int = 2):
        super().__init__(message)
        self.exit_code = exit_code


def read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8-sig")
    except (OSError, UnicodeError) as exc:
        raise BoardError(f"无法读取 UTF-8 文件：{path}", 10) from exc


def load_json(path: Path) -> dict:
    try:
        return json.loads(read_text(path))
    except json.JSONDecodeError as exc:
        raise BoardError(f"{path.name} 的 JSON 无效（第 {exc.lineno} 行，第 {exc.colno} 列）。") from exc


def write_bytes(path: Path, data: bytes) -> None:
    temporary = None
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with NamedTemporaryFile(dir=path.parent, delete=False) as file:
            temporary = Path(file.name)
            file.write(data)
        temporary.replace(path)
    except OSError as exc:
        raise BoardError(f"无法写入输出文件：{path}", 10) from exc
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def require_type(value, expected, field):
    valid = value is None or type(value) is expected
    if expected is str and isinstance(value, str):
        valid = bool(value.strip()) and len(value) <= 600 and value.isprintable()
    if expected is int and type(value) is int:
        valid = value > 0
    if expected is list and isinstance(value, list):
        valid = all(isinstance(item, str) and item.strip() and item.isprintable()
                    and len(item) <= 160 for item in value)
    if not valid:
        raise BoardError(f"scene_spec.json 的 {field} 格式无效。请参照场景字段说明。")


def require_object(value, keys, field):
    if not isinstance(value, dict):
        raise BoardError(f"scene_spec.json 的 {field} 应为对象。")
    missing = set(keys) - value.keys()
    unexpected = value.keys() - set(keys)
    if missing or unexpected:
        details = []
        if missing:
            details.append(f"缺少 {', '.join(sorted(missing))}")
        if unexpected:
            details.append(f"未知字段 {', '.join(sorted(unexpected))}")
        raise BoardError(f"scene_spec.json 的 {field}：{'，'.join(details)}。")
    return value


def at_path(scene: dict, path: str):
    value = scene
    for part in path.split("."):
        if not isinstance(value, dict) or part not in value:
            raise KeyError(path)
        value = value[part]
    return value


FLORAL_FIELDS = {"materials": list, "colors": list, "position": str, "volume": str}
GROUP_FIELDS = {
    "venue": {"type": str, "description": str},
    "backdrop": {"material": str, "form": str, "spans": int, "beam": str, "post": str},
    "drapery": {"colors": list, "material": str, "hanging": str},
    "florals.main": FLORAL_FIELDS,
    "florals.side": FLORAL_FIELDS,
    "florals.ground": FLORAL_FIELDS,
    "stage": {"shape": str, "material": str, "scale_impression": str},
    "aisle_and_ground": {"aisle": str, "ground": str},
    "seating": {"style": str, "rows": int, "columns": int, "decoration": str, "arrangement": str},
    "lighting_props": {"lighting": str, "props": list},
}


def validate_group(scene: dict, field: str, fields: dict) -> None:
    group = require_object(at_path(scene, field), {"status", *fields}, field)
    if not isinstance(group["status"], str) or group["status"] not in STATUSES:
        raise BoardError(f"scene_spec.json 的 {field}.status 必须是 {', '.join(sorted(STATUSES))} 之一。")
    for name, expected_type in fields.items():
        require_type(group[name], expected_type, f"{field}.{name}")
    has_evidence = any(group[name] is not None and group[name] != [] for name in fields)
    if (group["status"] in AVAILABLE) != has_evidence:
        raise BoardError(f"scene_spec.json 的 {field} 状态和可见内容不一致。")


def load_scene(path: Path) -> dict:
    scene = require_object(
        load_json(path),
        {"schema_version", "theme", "palette", "florals", "inferred", "uncertain",
         *(key for key in GROUP_FIELDS if "." not in key)},
        "顶层",
    )
    if scene["schema_version"] != "1.0":
        raise BoardError("scene_spec.json 的 schema_version 必须为字符串 \"1.0\"。")
    theme = require_object(scene["theme"], {"zh", "en", "style"}, "theme")
    for name, maximum in (("zh", 18), ("en", 48), ("style", 180)):
        value = theme[name]
        if not isinstance(value, str) or not value.strip() or not value.isprintable() or len(value) > maximum:
            raise BoardError(f"scene_spec.json 的 theme.{name} 需要 1–{maximum} 个可打印字符。")
    palette = require_object(scene["palette"], {"primary", "secondary"}, "palette")
    for key, colors in palette.items():
        if not isinstance(colors, list) or len(colors) > 8 or (key == "primary" and not colors):
            raise BoardError(f"scene_spec.json 的 palette.{key} 需要有效的色板数组。")
        for color in colors:
            require_object(color, {"name", "hex"}, f"palette.{key}[]")
            require_type(color["name"], str, f"palette.{key}[].name")
            if color["name"] is None or not isinstance(color["hex"], str) or not re.fullmatch(r"#[0-9A-Fa-f]{6}", color["hex"]):
                raise BoardError("色板的每个色样需要名称和形如 #2B2D31 的近似 HEX。")
    require_object(scene["florals"], {"main", "side", "ground"}, "florals")
    for field, fields in GROUP_FIELDS.items():
        validate_group(scene, field, fields)
    for kind in ("inferred", "uncertain"):
        items = scene[kind]
        if not isinstance(items, list):
            raise BoardError(f"scene_spec.json 的 {kind} 应为数组。")
        for item in items:
            require_object(item, {"target", "description"}, f"{kind}[]")
            for key in ("target", "description"):
                require_type(item[key], str, f"{kind}[].{key}")
                if item[key] is None:
                    raise BoardError(f"scene_spec.json 的 {kind}[].{key} 需要非空文字。")
            if item["target"] != "hardware":
                try:
                    at_path(scene, item["target"])
                except KeyError as exc:
                    raise BoardError(f"{kind} 的 target 必须指向场景字段或 hardware。") from exc
    return scene


def load_layout(path: Path | None = None) -> dict:
    layout = load_json(path or ROOT / "assets" / "board-layout.json")
    required = {"canvas", "background", "header", "headings", "line_segments", "surface_regions",
                "callout_zone", "callouts", "grid", "components"}
    if not isinstance(layout, dict) or not required.issubset(layout):
        raise BoardError("版式文件缺少必需字段。请以 assets/board-layout.json 为模板。")
    if layout["background"] != "#2B2D31":
        raise BoardError("展板底色需统一使用 #2B2D31。")
    regions = layout["surface_regions"]
    if not isinstance(regions, list) or not regions:
        raise BoardError("surface_regions 至少需要一个文字或留白区域。")
    for index, region in enumerate(regions, start=1):
        if (not isinstance(region, list) or len(region) != 4
                or any(type(value) not in (int, float) or not 0 <= value <= 100 for value in region)
                or not (region[0] < region[2] and region[1] < region[3])):
            raise BoardError(f"surface_regions 第 {index} 项需为按左、上、右、下排列的百分比矩形。")
    return layout


def active(scene: dict, source: str) -> bool:
    if source == "hardware":
        return active(scene, "backdrop") and any(item["target"] == "hardware" for item in scene["inferred"])
    item = at_path(scene, source)
    if isinstance(item, dict):
        return item["status"] in AVAILABLE
    return bool(item) and active(scene, source.rsplit(".", 1)[0])


def board_title(scene: dict) -> list[str]:
    theme = scene["theme"]
    return [f"{theme['zh'].strip()}婚礼背景｜立体场景资产拆解图",
            f"{theme['en'].strip().upper()} WEDDING BACKDROP | 3D SCENE ASSET BREAKDOWN"]


def callouts(scene: dict, layout: dict) -> list[dict]:
    labels = []
    for index, spec in enumerate(layout["callouts"]):
        if active(scene, spec["source"]):
            labels.append({**spec, "index": index})
        elif spec["source"] == "backdrop.beam" and "fallback" in spec and active(scene, "backdrop.form"):
            labels.append({**spec, "index": index, "text": spec["fallback"]})
    return labels


def grid_rows(scene: dict, layout: dict) -> list[list[dict]]:
    components = [spec for spec in layout["components"] if active(scene, spec["source"])][:9]
    grass_words = ("草地", "草坪", "草皮", "grass", "lawn")
    for index, spec in enumerate(components):
        if spec["source"] == "aisle_and_ground":
            ground = (scene["aisle_and_ground"]["ground"] or "").lower()
            if "fallback" in spec and not any(word in ground for word in grass_words):
                components[index] = {**spec, "text": spec["fallback"]}
    split = (len(components) + 1) // 2
    return [components[:split], components[split:]]


def parse_size(value: str) -> tuple[int, int]:
    match = re.fullmatch(r"(\d{2,5})[xX×](\d{2,5})", value.strip())
    if not match:
        raise BoardError("尺寸格式为 宽x高，例如 1536x2048。", 7)
    width, height = (int(part) for part in match.groups())
    if not 384 <= width <= 3072 or 4 * width != 3 * height:
        raise BoardError("成品需要 3:4 竖版，宽度范围 384–3072 像素。例如 1536x2048。", 7)
    return width, height
