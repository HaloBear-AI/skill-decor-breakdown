# HaloBear 婚礼布置解析全案图

上传一张仪式区、舞台、迎宾区等布置参考图，生成一张竖版双语解析展板。展板含等距全景、正立面与平面、爆炸轴测、单体组件网格。配套交付场景 JSON、完整提示词及质检说明。适用于提案和视觉交底，施工尺寸与节点需另行核实。

v1.1.0 统一两侧页边距和各列对齐线，拉开图文间距。底部两行标签采用一致的内缩，组件在各自图像区内居中。标题、标注及标签直接排在纯炭灰 `#2B2D31` 板面上，中文分粗体和中等字重，灰白英文副标较小。叠字按可见字形对齐中英文左边缘。直接出图优先使用无字底图叠字。

## 策划师怎么用

1. 在已安装 Skill 的项目里打开对话，选择能读图的模型。只上传一张清晰的场景图，支持 PNG、JPG/JPEG 和 WebP。
2. 选中 `decor-breakdown`，或发送「请把这张婚礼布置图做成一张 3:4 双语解析全案图，按原图保留布幔、花艺、舞台和座椅排布。」
3. 查看 PNG 与交付说明，核对图文对齐、分区留白、底色、引线落点和现场看不到的部位。若无法直接生成，会给你可复制的完整提示词。把原图一并上传到支持参考图的生图工具，选 3:4 竖版和高质量，建议 1536 × 2048。

## 安装与调用

解压后保留完整文件夹名 `decor-breakdown`。表里的路径是存放此文件夹的父目录。选一个对应作用域即可。项目级路径从仓库根目录算起。个人级路径用 `~` 表示当前用户目录。

| 宿主 | 项目级 | 个人级 | 调用 |
| --- | --- | --- | --- |
| Codex | `.agents/skills/` | `~/.agents/skills/` | 在桌面的 Skills 或输入框选择。CLI 或 IDE 用 `/skills` 或 `$decor-breakdown`。 [Codex 文档](https://learn.chatgpt.com/docs/build-skills#how-chatgpt-and-codex-use-skills) |
| Claude Code | `.claude/skills/` | `~/.claude/skills/` | 输入 `/decor-breakdown`。 [Claude Code 文档](https://code.claude.com/docs/en/skills) |
| Cursor | `.agents/skills/` 或 `.cursor/skills/` | `~/.agents/skills/` 或 `~/.cursor/skills/` | 在 Agent 聊天输入 `/` 并选此 Skill。 [Cursor 文档](https://cursor.com/docs/skills) |
| Gemini CLI | `.agents/skills/` 或 `.gemini/skills/` | `~/.agents/skills/` 或 `~/.gemini/skills/` | 用 `/skills list` 确认已加载，再在请求里指名使用。新装可用 `/skills reload`。 [Gemini CLI 文档](https://geminicli.com/docs/cli/skills/) |
| GitHub Copilot CLI | `.agents/skills/`、`.github/skills/` 或 `.claude/skills/` | `~/.agents/skills/` 或 `~/.copilot/skills/` | 输入 `/decor-breakdown`，用 `copilot skill list` 查看本地发现结果。 [Copilot CLI 文档](https://docs.github.com/en/copilot/reference/copilot-cli-reference/cli-command-reference#skills-reference) |
| GitHub Copilot（VS Code） | `.github/skills/` | `~/.copilot/skills/` | 在 Agent 聊天输入 `/` 并选此 Skill。 [VS Code 文档](https://code.visualstudio.com/docs/agent-customization/agent-skills) |

可从同一个解压版本部署多个目录。以下命令在解压出的 Skill 根目录运行，把示例项目路径换成你的项目路径。Windows 同样适用，可用 `py -3.11` 替换 `python`。

```text
python scripts/install_skill.py "../你的项目/.agents/skills" "../你的项目/.claude/skills"
```

也可直接复制整个文件夹。升级时先备份已有版本，再从同一 ZIP 部署。对话中看不到 Skill 时，在对应项目里新开对话或刷新 Skill 列表，并确认目标宿主允许读取工作区 Skill。

## 生图与环境变量

脚本需要 Python 3.10 或更新版本。若系统 `python3` 指向旧版本，请使用设备上较新的解释器。安装脚本生图和本地图片处理依赖。

```text
python -m pip install -r requirements.txt
python scripts/generate_board.py --probe
```

在运行智能体的环境中设置下列一组密钥。桌面宿主使用其支持的环境变量或密钥设置，终端宿主需要能把环境变量传给子进程。可用 [.env.example](.env.example) 对照字段。

| 路径 | 运行条件 |
| --- | --- |
| A · OpenAI | `OPENAI_API_KEY`。默认 `gpt-image-2.6-sunburst` |
| A · Gemini | `GEMINI_API_KEY` 或 `GOOGLE_API_KEY`。默认 `gemini-3-pro-image` |
| A · 兼容网关 | `WEDDING_BOARD_BASE_URL`、`WEDDING_BOARD_API_KEY`、`WEDDING_BOARD_MODEL`。模型与原生尺寸按网关文档设置 |
| B · 宿主 | 宿主能用参考图生成文件，并支持下载或导出 |
| C · 手动提示词包 | 由当前视觉模型读图并组装提示词，用户在支持参考图的工具出图 |

可用 `WEDDING_BOARD_PROVIDER` 或 `--provider` 指定 `openai`、`gemini`、`generic`。自动检测按此顺序。可选变量还包括 `WEDDING_BOARD_MODEL`、`WEDDING_BOARD_TIMEOUT`、`WEDDING_BOARD_FONT` 及网关尺寸和字段开关。实际生成会将参考图与提示词交给所选服务。按账户权限、模型开放范围和网关协议运行。 [后端参数与官方接口](references/provider-notes.md)

建议安装思源黑体或 Noto Sans CJK SC，优先使用提供中等和粗体字重的家族。也可把 `WEDDING_BOARD_FONT` 设为能覆盖本次文字的 `.ttf`、`.otf` 或 `.ttc` 文件路径。叠字前会检查实际需要的字形。

## 离线试算与脚本入口

下面的 `reference.jpg` 是你提供的一张图像。演示的 JSON 已附在包内。正式生成时从当前参考图重写 `scene_spec.json`，以保证参考图、描述和提示词对应。

```text
python scripts/build_prompt.py --scene-spec references/example-scene-spec.json --out output/prompt-model.txt --text-mode model
python scripts/build_prompt.py --scene-spec references/example-scene-spec.json --out output/prompt-overlay.txt --text-mode overlay
python scripts/generate_board.py --reference reference.jpg --prompt-file output/prompt-overlay.txt --text-mode overlay --scene-spec references/example-scene-spec.json --out output/board.png --provider openai --dry-run
```

`--dry-run` 校验图像、提示词和请求计划，显示模型、原生尺寸及实际请求参数。按需将 `--provider openai` 换成 `gemini` 或 `generic`，generic 未配置时用试算占位值。有可用密钥后移除 `--dry-run` 即可请求生图。用 `--size 1536x2048` 指定最终画布，支持宽 384–3072 像素的精确 3:4 尺寸，默认 `--quality high`。原生尺寸回退时，脚本记录实际尺寸并等比缩放，用 `#2B2D31` 补边。

直接出图按示例显式选择 `--text-mode overlay`，使用对应的提示词及场景描述。命令行省略 `--text-mode` 时沿用 `model`，搭配 `prompt-model.txt`。从宿主拿到无字底图后，使用独立叠字脚本。

```text
python scripts/overlay_text.py --image output/no-text.png --scene-spec output/scene_spec.json --out output/board.png
```

叠字时，脚本检查预留区有无明显物件侵入，再在符合条件的区域铺回统一底色。生成和独立叠字均可通过 `--layout-file` 指定布局 JSON，用于微调对齐、留白和引线落点。宿主已生成文字时，可用 `--normalize-only` 转成 3:4 PNG。两种模式都要复核排版、底色、字重、引线和场景。[质检清单](references/qa-checklist.md)

### 常见失败

| 退出码 | 含义 |
| --- | --- |
| 2 | 输入图、场景字段、提示词或命令行参数有误 |
| 3 | 后端配置缺失、无效，或不支持所选模型 |
| 4 | 鉴权或权限失败 |
| 5 | 内容审核拒绝 |
| 6 | 网络请求超时 |
| 7 | 图像尺寸无效或服务不支持该尺寸 |
| 8 | 依赖或中文字体缺失 |
| 9 | 其他请求、响应、配额或成图异常 |
| 10 | 本地文件操作失败 |

## 文件清单

- [SKILL.md](SKILL.md) 指挥从读图到验收的通用流程。
- [脚本](scripts/) 包含提示词组装、生成、叠字与画布归一化、安装，以及三个后端适配器。
- [场景字段](references/scene-spec-schema.md)和[完整示例](references/example-scene-spec.json)用于采集证据。
- [版式坐标](references/board-layout-spec.md)、[术语表](references/wedding-decor-taxonomy.md)、[后端说明](references/provider-notes.md)及[质检清单](references/qa-checklist.md)用于生成与复核。
- [模型及叠字模板](assets/prompt-template.md)和[版式坐标数据](assets/board-layout.json)共用固定构图。
- [依赖表](requirements.txt)、[环境变量模板](.env.example)及[许可](LICENSE)随包提供。

## 已知局限

单张图呈现的是可见关系。背面、具体花种、受遮挡的场地排布和连接方式可能需要重建，已用 `inferred` 和 `uncertain` 记录。成图的多视角一致性、标注落点和小字可读性受实际图像模型能力影响。叠字可确定字形和位置，底图中的组件位置仍须复查。
