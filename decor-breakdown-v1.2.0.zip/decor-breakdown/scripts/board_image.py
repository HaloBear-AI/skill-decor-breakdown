"""Decode image files and fit board artwork to an exact 3:4 canvas."""

from io import BytesIO
from pathlib import Path

from board_spec import BoardError, write_bytes

FORMATS = {
    ".jpg": "JPEG",
    ".jpeg": "JPEG",
    ".png": "PNG",
    ".webp": "WEBP",
}
MIME_TYPES = {"JPEG": "image/jpeg", "PNG": "image/png", "WEBP": "image/webp"}
MAX_PIXELS = 48_000_000
MAX_INPUT_BYTES = 50_000_000


def pillow():
    try:
        from PIL import Image, ImageOps
    except ImportError as exc:
        raise BoardError("缺少 Pillow。请用当前 Python 安装 requirements.txt 所列依赖。", 8) from exc
    return Image, ImageOps


def open_image(source, description: str, exit_code: int = 2):
    Image, ImageOps = pillow()
    try:
        with Image.open(source, formats=tuple(MIME_TYPES)) as image:
            if image.width * image.height > MAX_PIXELS:
                raise BoardError(f"{description}超过 4800 万像素，请先缩小。", exit_code)
            if getattr(image, "n_frames", 1) != 1:
                raise BoardError(f"{description}需要一张静态图。", exit_code)
            fmt = image.format
            return ImageOps.exif_transpose(image), fmt
    except (OSError, ValueError, Image.DecompressionBombError) as exc:
        raise BoardError(f"{description}无法解码。请使用有效的 PNG、JPEG 或 WebP 图像。", exit_code) from exc


def check_reference(path: Path) -> str:
    expected = FORMATS.get(path.suffix.lower())
    if not expected or not path.is_file():
        raise BoardError("请提供一张可读的 PNG、JPG/JPEG 或 WebP 参考图。")
    if path.stat().st_size > MAX_INPUT_BYTES:
        raise BoardError("参考图超过 50 MB，请先缩小。")
    _, actual = open_image(path, "参考图")
    if expected != actual:
        raise BoardError("参考图的文件后缀与真实图像格式不一致。")
    return MIME_TYPES[actual]


def fit_canvas(image, size: tuple[int, int], background: str):
    Image, ImageOps = pillow()
    tile = ImageOps.contain(image.convert("RGBA"), size, Image.Resampling.LANCZOS)
    left = (size[0] - tile.width) // 2
    top = (size[1] - tile.height) // 2
    board = Image.new("RGB", size, background)
    board.paste(tile, (left, top), tile.getchannel("A"))
    content = (left, top, left + tile.width, top + tile.height)
    return board, content


def decode_result(data: bytes):
    image, _ = open_image(BytesIO(data), "生图服务返回的图片", 9)
    return image


def save_png(image, path: Path) -> None:
    if path.suffix.lower() != ".png":
        raise BoardError("成品输出需要使用 .png 后缀。")
    buffer = BytesIO()
    image.save(buffer, format="PNG")
    write_bytes(path, buffer.getvalue())
