"""Copy this package to one or more host skill directories."""

import argparse
import shutil
import sys
from pathlib import Path
from tempfile import TemporaryDirectory

from board_spec import ROOT

FILES = ("SKILL.md", "README.md", "LICENSE", "requirements.txt", ".env.example")
DIRECTORIES = ("assets", "references", "scripts")


def install(skills_folder: Path) -> Path:
    destination = skills_folder / ROOT.name
    if destination.resolve() == ROOT or destination.is_relative_to(ROOT):
        raise ValueError("安装目标需要在当前 Skill 文件夹之外。")
    if destination.exists() or destination.is_symlink():
        raise FileExistsError(f"已经存在 {destination}。请为已有版本保留备份，再安装。")
    skills_folder.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(prefix=".wedding-board-install-", dir=skills_folder) as folder:
        staged = Path(folder) / ROOT.name
        staged.mkdir()
        for name in FILES:
            shutil.copy2(ROOT / name, staged / name)
        for name in DIRECTORIES:
            shutil.copytree(
                ROOT / name, staged / name,
                ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".DS_Store", ".env"),
            )
        if destination.exists() or destination.is_symlink():
            raise FileExistsError(f"安装目标已存在：{destination}")
        staged.rename(destination)
    return destination


def main() -> int:
    parser = argparse.ArgumentParser(description="将同一份 Skill 安装到指定的一个或多个 skills 目录。")
    parser.add_argument("destinations", type=Path, nargs="+", metavar="SKILLS_DIR")
    args = parser.parse_args()
    try:
        for folder in args.destinations:
            target = install(folder.expanduser().resolve())
            print(f"已安装 {target}")
        return 0
    except (ValueError, OSError) as exc:
        print(str(exc), file=sys.stderr)
        return 10


if __name__ == "__main__":
    raise SystemExit(main())
