"""Build a copy-ready image prompt from a validated scene record."""

import argparse
import re
import sys
from pathlib import Path
from string import Template

from board_spec import (
    ROOT, BoardError, at_path, board_title, callouts, grid_rows, load_layout,
    load_scene, read_text, write_bytes,
)

GROUP_LABELS = {
    "venue": ("场地", {"type": "类型", "description": "视觉特征"}),
    "backdrop": ("背景结构", {"material": "材质", "form": "形式", "spans": "可确认跨数", "beam": "横梁", "post": "立柱"}),
    "drapery": ("布幔", {"colors": "颜色", "material": "质感", "hanging": "悬挂方式"}),
    "florals.main": ("主背景花艺", {"materials": "花材形态", "colors": "颜色", "position": "位置", "volume": "体量"}),
    "florals.side": ("侧边花艺", {"materials": "花材形态", "colors": "颜色", "position": "位置", "volume": "体量"}),
    "florals.ground": ("地面花艺", {"materials": "花材形态", "colors": "颜色", "position": "位置", "volume": "体量"}),
    "stage": ("舞台", {"shape": "轮廓", "material": "表面质感", "scale_impression": "尺寸感"}),
    "aisle_and_ground": ("通道与地面", {"aisle": "通道", "ground": "地面"}),
    "seating": ("座椅", {"style": "款式", "rows": "可确认行数", "columns": "可确认列数",
                         "decoration": "装饰", "arrangement": "方向和排布"}),
    "lighting_props": ("灯光与道具", {"lighting": "可见光效", "props": "可见道具"}),
}
STATUS_TEXT = {
    "visible": "可见",
    "partial": "仅部分可见",
    "not_visible": "无法由输入确认",
    "absent": "可见范围内未出现",
}


def describe_scene(scene: dict) -> str:
    theme = scene["theme"]
    lines = [f"- 主题「{theme['zh']}」，风格为{theme['style']}。"]
    for key, label in (("primary", "主色"), ("secondary", "辅色")):
        colors = "、".join(f"{item['name']}（{item['hex'].upper()}）" for item in scene["palette"][key])
        if colors:
            lines.append(f"- {label}（近似）为{colors}。")
    for source, (label, fields) in GROUP_LABELS.items():
        group = at_path(scene, source)
        details = []
        for key, field_label in fields.items():
            value = group[key]
            if value:
                detail = "、".join(value) if isinstance(value, list) else str(value)
                details.append(f"{field_label}为{detail}")
        line = f"- {label}（{STATUS_TEXT[group['status']]}）"
        lines.append(line + "，" + "。".join(details) + "。" if details else line + "。")
    for key, heading in (
        ("inferred", "推断项，仅用于必要的视觉补全"),
        ("uncertain", "不确定项，保留中性表达"),
    ):
        if scene[key]:
            lines += ["", heading]
            lines.extend(f"- {item['description']}" for item in scene[key])
    return "\n".join(lines)


def pair(label: list[str]) -> str:
    return f"「{label[0]}」 / 「{label[1]}」"


def build_prompt(scene: dict, mode: str, feedback: str = "") -> str:
    layout = load_layout()
    labels = callouts(scene, layout)
    rows = grid_rows(scene, layout)
    callout_names = [
        f"{label['text'][0]}（参考落点 x={label['anchor'][0]:g}%、y={label['anchor'][1]:g}%）"
        for label in labels
    ]
    geometry = " 需要保留的组件位置为" + "、".join(callout_names) + "。" if labels else ""
    grid = []
    row_names = ("第一行", "第二行")
    for name, row in zip(row_names, rows):
        if row:
            grid.append(f"{name}从左到右为{'、'.join(item['text'][0] for item in row)}，该行各格等宽")
        else:
            grid.append(f"{name}保留深灰留白")
    copy = [f"- 顶部标题用 {pair(board_title(scene))}。"]
    copy.extend(f"- 对应板块上方用 {pair(item['text'])}。" for item in layout["headings"])
    if labels:
        copy.append(f"- 爆炸图右侧从上到下用 {'、'.join(pair(item['text']) for item in labels)}。")
    for name, row in zip(row_names, rows):
        if row:
            copy.append(f"- 素材网格{name}从左到右用 {'、'.join(pair(item['text']) for item in row)}。")
    template = read_text(ROOT / "assets" / "prompt-template.md")
    sections = re.split(r"(?m)^<!-- (common|model|overlay) -->\s*$", template)
    versions = dict(zip(sections[1::2], sections[2::2]))
    if set(versions) != {"common", "model", "overlay"}:
        raise BoardError("提示词模板的文字模式区块缺失。")
    rendered = Template(versions["common"].strip() + "\n\n" + versions[mode].strip()).substitute(
        scene_details=describe_scene(scene),
        callout_geometry=geometry,
        grid_geometry="\n\n" + "。\n".join(grid) + "。",
        board_copy="\n".join(copy),
    )
    if feedback.strip():
        rendered += "\n\n本轮复核要求，沿用前述场景事实与文字模式。\n\n" + feedback.strip()
    return rendered + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description="从场景描述组装可直接交给生图模型的提示词。")
    parser.add_argument("--scene-spec", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--text-mode", choices=("model", "overlay"), default="model")
    parser.add_argument("--feedback-file", type=Path, help="本轮只修正已发现的具体问题。")
    args = parser.parse_args()
    try:
        inputs = [args.scene_spec, args.feedback_file]
        if any(path is not None and path.resolve() == args.out.resolve() for path in inputs):
            raise BoardError("提示词输出路径必须与输入文件不同。")
        scene = load_scene(args.scene_spec)
        feedback = read_text(args.feedback_file) if args.feedback_file else ""
        prompt = build_prompt(scene, args.text_mode, feedback)
        write_bytes(args.out, prompt.encode("utf-8"))
        print(f"提示词已写入 {args.out}（{args.text_mode}）")
        return 0
    except (BoardError, OSError) as exc:
        print(str(exc), file=sys.stderr)
        return getattr(exc, "exit_code", 10)


if __name__ == "__main__":
    raise SystemExit(main())
