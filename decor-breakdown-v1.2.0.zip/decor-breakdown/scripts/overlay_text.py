"""Render the bilingual labels or normalize a host-generated board."""

import argparse
import os
import sys
from functools import lru_cache
from pathlib import Path

from board_image import fit_canvas, open_image, save_png
from board_spec import (
    DEFAULT_SIZE, BoardError, board_title, callouts, grid_rows,
    load_layout, load_scene, parse_size,
)

BODY_NAMES = (
    "NotoSansCJKsc-Medium.otf", "SourceHanSansSC-Medium.otf", "SourceHanSansCN-Medium.otf",
    "NotoSansCJK-Medium.otf",
    "NotoSansCJK-Regular.otf", "PingFang.ttc", "STHeiti Medium.ttc", "Hiragino Sans GB.ttc",
    "NotoSansCJK-Regular.ttc", "NotoSansCJKsc-Regular.otf", "NotoSansSC-Regular.ttf",
    "SourceHanSansSC-Regular.otf", "SourceHanSansCN-Regular.otf", "SourceHanSansCN-Normal.otf",
    "wqy-zenhei.ttc", "msyh.ttc", "simhei.ttf", "simsun.ttc",
)
HEADING_NAMES = (
    "SourceHanSerifSC-Medium.otf", "SourceHanSerifCN-Medium.otf", "NotoSerifCJKsc-Medium.otf",
    "SourceHanSerifSC-Regular.otf", "SourceHanSerifCN-Regular.otf", "NotoSerifCJKsc-Regular.otf",
    "NotoSerifSC-Regular.ttf", "SourceHanSerifSC-VF.otf", "NotoSerifCJK-Regular.ttc",
    "NotoSerifCJKsc-VF.otf", "NotoSerifSC[wght].ttf", "Songti.ttc", "simsun.ttc",
)
BOLD_BODY_NAMES = (
    "NotoSansCJK-Bold.otf", "NotoSansCJKsc-Bold.otf", "NotoSansCJK-Bold.ttc",
    "SourceHanSansSC-Bold.otf", "msyhbd.ttc",
)
ENGLISH_HEADING_NAMES = (
    "LibreBaskerville-Regular.ttf", "Baskervville-Regular.ttf", "Baskerville.ttc",
    "NotoSerif-Regular.ttf", "Georgia.ttf", "georgia.ttf", "LiberationSerif-Regular.ttf", "DejaVuSerif.ttf",
)
ENGLISH_NAMES = (
    "Inter-Medium.ttf", "Inter-Regular.ttf", "InterVariable.ttf", "DejaVuSans.ttf", "Arial.ttf", "arial.ttf",
)


def font_directories():
    home = Path.home()
    if sys.platform == "darwin":
        return (home / "Library" / "Fonts", Path("/Library/Fonts"), Path("/System/Library/Fonts"))
    elif os.name == "nt":
        return (Path(os.environ.get("WINDIR", r"C:\Windows")) / "Fonts",
                home / "AppData" / "Local" / "Microsoft" / "Windows" / "Fonts")
    return (home / ".local" / "share" / "fonts", home / ".fonts",
            Path("/usr/local/share/fonts"), Path("/usr/share/fonts"))


def choose_fonts(scene: dict, layout: dict) -> dict[str, tuple[Path, int]]:
    try:
        from fontTools.ttLib import TTCollection, TTFont, TTLibError
        from PIL import ImageFont
    except ImportError as exc:
        raise BoardError("文字叠加需要 Pillow 和 fonttools。请安装 requirements.txt。", 8) from exc
    headings = [board_title(scene), *(item["text"] for item in layout["headings"])]
    pairs = headings + [item["text"] for item in callouts(scene, layout)]
    pairs.extend(item["text"] for row in grid_rows(scene, layout) for item in row)

    def coverage(lines):
        return {ord(char) for line in lines for char in line if not char.isspace()}

    @lru_cache(maxsize=32)
    def faces(path):
        supported = []
        try:
            with path.open("rb") as file:
                collection_file = file.read(4) == b"ttcf"
            if collection_file:
                with TTCollection(path, lazy=True) as collection:
                    faces = len(collection.fonts)
            else:
                faces = 1
            for index in range(faces):
                with TTFont(path, fontNumber=index, lazy=True) as font:
                    glyphs = font.getBestCmap() or {}
                    supported.append((index, {code for code, glyph in glyphs.items() if glyph != ".notdef"}))
        except (OSError, TTLibError, ValueError, KeyError):
            pass
        return supported

    def find_font(paths, required):
        for path in paths:
            for index, codepoints in faces(path):
                if required <= codepoints:
                    try:
                        ImageFont.truetype(str(path), size=20, index=index)
                    except OSError:
                        continue
                    return path, index
        return None

    chinese = coverage(pair[0] for pair in pairs)
    english = coverage(pair[1] for pair in pairs)
    override = os.environ.get("WEDDING_BOARD_FONT", "").strip()
    if override:
        paths = [Path(override).expanduser()]
        body = find_font(paths, chinese | english)
        heading = heading_latin = latin = body
    else:
        directories = font_directories()

        def candidates(names):
            for name in names:
                for directory in directories:
                    yield from directory.rglob(name)

        body = find_font(candidates(BODY_NAMES + BOLD_BODY_NAMES + HEADING_NAMES), chinese | english)
        heading = find_font(candidates(HEADING_NAMES), coverage(pair[0] for pair in headings)) or body
        latin = find_font(candidates(ENGLISH_NAMES), english) or body
        heading_latin = find_font(candidates(ENGLISH_HEADING_NAMES), coverage(pair[1] for pair in headings)) or latin
    if body is None:
        raise BoardError(
            "找不到能覆盖本次中英文标注的字体。请安装思源黑体或 Noto Sans CJK SC，"
            "或设置 WEDDING_BOARD_FONT 指向可读的 .ttf、.otf 或 .ttc 字体文件。", 8,
        )
    return {"heading": heading, "heading_english": heading_latin, "body": body, "english": latin}


def normalize_surfaces(image, boxes, background):
    from PIL import ImageChops

    # Inspect every reserved rectangle before painting any of them.
    for index, box in enumerate(boxes, start=1):
        red, green, blue = image.crop(box).split()
        lightest = ImageChops.lighter(ImageChops.lighter(red, green), blue)
        darkest = ImageChops.darker(ImageChops.darker(red, green), blue)
        span = ImageChops.subtract(lightest, darkest)
        if lightest.getextrema()[1] > 104 or span.getextrema()[1] > 25:
            raise BoardError(
                f"第 {index} 个底色区域含亮色或彩色内容。请重新预留底图留白或校准 --layout-file，以保护场景资产。",
                9,
            )
    for box in boxes:
        image.paste(background, box)


def render_overlay(image, content, scene: dict, layout: dict, fonts):
    from PIL import Image, ImageDraw, ImageFont

    draw = ImageDraw.Draw(image)
    left, top, right, bottom = content
    width, height = right - left, bottom - top
    design_w, design_h = layout["canvas"]
    scale = min(width / design_w, height / design_h)
    line_width = max(1, round(scale))
    radius = max(1, round(2.0 * scale))

    def point(x, y):
        return (left + width * x / 100, top + height * y / 100)

    surfaces = [
        tuple(round(coordinate) for coordinate in (*point(x1, y1), *point(x2, y2)))
        for x1, y1, x2, y2 in layout["surface_regions"]
    ]
    normalize_surfaces(image, surfaces, layout["background"])

    @lru_cache(maxsize=64)
    def font(role, size):
        path, index = fonts[role]
        return ImageFont.truetype(str(path), size, index=index)

    def pair(lines, x, y, max_width, sizes, role="body"):
        px, py = (round(coordinate) for coordinate in point(x, y))
        limit = width * max_width / 100
        faces = (role, "heading_english" if role == "heading" else "english")
        colors = ("#F5EBDD", "#E1D2BE") if role == "heading" else ("#F2EFEB", "#DAD4CC")
        for label, target_size, face, color in zip(lines, sizes, faces, colors):
            size = max(1, round(target_size * scale))
            typeface = font(face, size)
            length = typeface.getlength(label)
            if length > limit:
                size = max(1, int(size * limit / length))
                typeface = font(face, size)
            x1, y1, x2, y2 = typeface.getbbox(label, anchor="lt")
            mask = Image.new("L", (x2 - x1, y2 - y1))
            ImageDraw.Draw(mask).text((-x1, -y1), label, fill=255, font=typeface, anchor="lt")
            ink = mask.getbbox()
            if ink is None:
                raise BoardError("双语标题与标注需要可见字形。")
            # Font side bearings vary between scripts and punctuation.
            mask = mask.crop(ink)
            right, bottom = px + mask.width, py + mask.height
            if not any(a <= px and b <= py and right <= c and bottom <= d for a, b, c, d in surfaces):
                raise BoardError(f"标注「{label}」超出留白区。请校准 --layout-file 后重试。", 9)
            image.paste(color, (px, py, right, bottom), mask)
            py = bottom + max(1, round(target_size * scale * 0.19))

    def line(points, color="#625D59"):
        draw.line([point(x, y) for x, y in points], fill=color, width=line_width)

    for x1, y1, x2, y2 in layout["line_segments"]:
        line([(x1, y1), (x2, y2)])
    pair(board_title(scene), *layout["header"], sizes=(52, 26), role="heading")
    for item in layout["headings"]:
        small = item["text"][0] in {"正立面图", "平面图"}
        pair(item["text"], *item["at"], sizes=(23, 16) if small else (30, 19),
             role="body" if small else "heading")

    zone = layout["callout_zone"]
    for item in callouts(scene, layout):
        label_y = item.get("label_y", zone["first_y"] + item["index"] * zone["step_y"])
        anchor_x, anchor_y = item["anchor"]
        rail_x = zone["rail_x"]
        line([(anchor_x, anchor_y), (rail_x - 1.3, anchor_y),
              (rail_x, label_y + 0.47), (zone["label_x"] - 0.5, label_y + 0.47)], "#A9A096")
        x, y = point(anchor_x, anchor_y)
        draw.ellipse((x - radius, y - radius, x + radius, y + radius), fill="#D4C9BC")
        pair(item["text"], zone["label_x"], label_y, zone["max_width"], sizes=(23, 15))

    grid = layout["grid"]
    vertical_bounds = [(grid["top"], grid["middle"]), (grid["middle"], grid["bottom"])]
    for row, (row_top, row_bottom) in zip(grid_rows(scene, layout), vertical_bounds):
        if not row:
            continue
        margin = grid["title_inset"]
        cell_width = (grid["right"] - grid["left"]) / len(row)
        line([(grid["left"], row_top), (grid["right"], row_top)])
        line([(grid["left"], row_bottom), (grid["right"], row_bottom)])
        for column, item in enumerate(row):
            x = grid["left"] + column * cell_width
            line([(x, row_top), (x, row_bottom)])
            pair(item["text"], x + margin, row_top + margin, cell_width - 2 * margin, sizes=(23, 16))
        line([(grid["right"], row_top), (grid["right"], row_bottom)])
    return image


def main() -> int:
    parser = argparse.ArgumentParser(description="归一成 3:4 PNG，或叠加固定双语标题、标注及引线。")
    parser.add_argument("--image", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--scene-spec", type=Path)
    parser.add_argument("--layout-file", type=Path, help="按底图校准的版式 JSON。")
    parser.add_argument("--size", default=DEFAULT_SIZE)
    parser.add_argument("--normalize-only", action="store_true", help="仅转换比例、尺寸和 PNG 格式。")
    args = parser.parse_args()
    try:
        sources = (args.image, args.scene_spec, args.layout_file)
        if any(args.out.resolve() == path.resolve() for path in sources if path is not None):
            raise BoardError("成品输出路径必须与输入文件不同。")
        if not args.normalize_only and args.scene_spec is None:
            raise BoardError("叠加文字需要 --scene-spec。")
        image, _ = open_image(args.image, "待处理展板")
        layout = load_layout(args.layout_file)
        board, content = fit_canvas(image, parse_size(args.size), layout["background"])
        if not args.normalize_only:
            scene = load_scene(args.scene_spec)
            fonts = choose_fonts(scene, layout)
            render_overlay(board, content, scene, layout, fonts)
            print("叠字字体 " + " / ".join(path.name for path, _ in fonts.values()))
        save_png(board, args.out)
        print(f"成品 {args.out}。原图 {image.width}x{image.height}，"
              f"成品 {board.width}x{board.height}，内容区 {content}。")
        return 0
    except (BoardError, OSError) as exc:
        print(str(exc), file=sys.stderr)
        return getattr(exc, "exit_code", 10)


if __name__ == "__main__":
    raise SystemExit(main())
