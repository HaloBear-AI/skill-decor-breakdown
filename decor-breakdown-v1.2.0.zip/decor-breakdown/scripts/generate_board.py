"""Send one reference image to one provider and save one 3:4 PNG."""

import argparse
import json
import sys
from pathlib import Path

from board_image import check_reference, decode_result, fit_canvas, save_png
from board_spec import DEFAULT_SIZE, OVERLAY_CUE, BoardError, load_layout, load_scene, parse_size, read_text
from overlay_text import choose_fonts, render_overlay
from providers import (
    PROVIDER_NAMES, ImageRequest, ProviderError, configured_provider,
    generate, plan_request, resolve_config,
)


def show_json(data: dict) -> None:
    print(json.dumps(data, ensure_ascii=False, indent=2))


def probe(provider: str | None, model: str | None) -> None:
    selected = provider or configured_provider()
    if selected is None:
        show_json({"configured": False, "provider": None, "message": "未检测到可用的生图服务配置。"})
        return
    config = resolve_config(selected, model, dry_run=False)
    show_json({"configured": True, "provider": config.name, "model": config.model})


def run(args) -> None:
    if args.probe:
        probe(args.provider, args.model)
        return
    if args.reference is None or args.prompt_file is None or args.out is None:
        raise BoardError("生成和试算均需要 --reference、--prompt-file 与 --out。")
    if len(args.reference) != 1:
        raise BoardError("请只提供一张参考图。")
    reference = args.reference[0]
    if args.out.suffix.lower() != ".png" or args.out.is_dir():
        raise BoardError("请将 --out 指定为 .png 文件。")
    scene_path = args.scene_spec or args.prompt_file.with_name("scene_spec.json")
    sources = [reference.resolve(), args.prompt_file.resolve(), scene_path.resolve()]
    if args.layout_file is not None:
        sources.append(args.layout_file.resolve())
    if args.out.resolve() in sources:
        raise BoardError("成品输出路径必须与输入文件不同。")
    size = parse_size(args.size)
    mime_type = check_reference(reference)
    prompt = read_text(args.prompt_file).strip()
    if not prompt:
        raise BoardError("提示词文件为空。")

    use_overlay = args.text_mode == "overlay"
    if use_overlay != (OVERLAY_CUE in prompt):
        raise BoardError("提示词的文字模式与 --text-mode 不匹配。请用 build_prompt.py 按相同模式重新生成。")
    layout = load_layout(args.layout_file)
    fonts = None
    if use_overlay:
        scene = load_scene(scene_path)
        fonts = choose_fonts(scene, layout)

    config = resolve_config(args.provider, args.model, dry_run=args.dry_run)
    request = ImageRequest(reference, mime_type, prompt, size[0], size[1], args.quality)
    plan = plan_request(config, request)
    summary = {
        "route": "A",
        "dry_run": args.dry_run,
        "provider": config.name,
        "model": config.model,
        "text_mode": args.text_mode,
        "target_size": list(size),
        "planned_native_size": [plan.width, plan.height],
        "parameters": plan.parameters,
        "notices": list(plan.notices),
    }
    if fonts is not None:
        summary["font"] = " / ".join(path.name for path, _ in fonts.values())
    if args.dry_run:
        summary["prompt"] = prompt
        show_json(summary)
        return

    image = decode_result(generate(config, request, plan))
    board, content = fit_canvas(image, size, layout["background"])
    if fonts is not None:
        render_overlay(board, content, scene, layout, fonts)
    save_png(board, args.out)
    summary.update(
        actual_native_size=list(image.size),
        final_size=list(board.size),
        content_box=list(content),
        padded=content != (0, 0, board.width, board.height),
        out=str(args.out),
    )
    show_json(summary)


def main() -> int:
    parser = argparse.ArgumentParser(description="按参考图和提示词生成一张 3:4 PNG。")
    parser.add_argument("--reference", type=Path, action="append", help="提供一张 PNG、JPG/JPEG 或 WebP 参考图。")
    parser.add_argument("--prompt-file", type=Path)
    parser.add_argument("--out", type=Path)
    parser.add_argument("--provider", choices=PROVIDER_NAMES)
    parser.add_argument("--model")
    parser.add_argument("--size", default=DEFAULT_SIZE, help="最终出图尺寸，默认 1536x2048。")
    parser.add_argument("--quality", choices=("auto", "low", "medium", "high"), default="high")
    parser.add_argument("--text-mode", choices=("model", "overlay"), default="model")
    parser.add_argument("--scene-spec", type=Path, help="叠字模式使用，默认取提示词同级的 scene_spec.json。")
    parser.add_argument("--layout-file", type=Path, help="按底图校准的版式 JSON。")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--dry-run", action="store_true", help="解析输入并打印请求计划，不联网。")
    mode.add_argument("--probe", action="store_true", help="只检查环境中的后端配置是否齐全，不联网。")
    args = parser.parse_args()
    try:
        run(args)
        return 0
    except (ProviderError, BoardError) as exc:
        print(str(exc), file=sys.stderr)
        return exc.exit_code
    except OSError:
        print("本地文件读取或写入失败，请检查文件路径和权限。", file=sys.stderr)
        return 10


if __name__ == "__main__":
    raise SystemExit(main())
