"""Resolve a configured backend and use the same plan for dry-run and generation."""

import math
import os
import re
from urllib.parse import urlsplit

from . import gemini, generic, openai
from ._shared import (
    CONFIG_ERROR,
    INPUT_ERROR,
    MIME_EXTENSIONS,
    SIZE_ERROR,
    ImageRequest,
    ProviderConfig,
    ProviderError,
    RequestPlan,
)


PROVIDER_NAMES = ("openai", "gemini", "generic")
_PROVIDERS = {"openai": openai, "gemini": gemini, "generic": generic}
_KEY_NAMES = {
    "openai": ("OPENAI_API_KEY",),
    "gemini": ("GEMINI_API_KEY", "GOOGLE_API_KEY"),
    "generic": ("WEDDING_BOARD_API_KEY",),
}


def _env(name: str) -> str:
    return os.environ.get(name, "").strip()


def _provider_name(value: str) -> str:
    name = value.strip().lower()
    if name not in _PROVIDERS:
        raise ProviderError("未知后端。请选择 openai、gemini 或 generic。", CONFIG_ERROR)
    return name


def _key(name: str) -> str | None:
    return next((value for variable in _KEY_NAMES[name] if (value := _env(variable))), None)


def configured_provider() -> str | None:
    """Find credentials and required settings in the environment without accessing the network."""
    configured = _env("WEDDING_BOARD_PROVIDER")
    names = (_provider_name(configured),) if configured else PROVIDER_NAMES
    for name in names:
        if not _key(name):
            continue
        if name == "generic" and not (_env("WEDDING_BOARD_BASE_URL") and _env("WEDDING_BOARD_MODEL")):
            continue
        return name
    return None


def _timeout() -> float:
    try:
        value = float(_env("WEDDING_BOARD_TIMEOUT") or "300")
    except ValueError:
        value = math.nan
    if not math.isfinite(value) or value <= 0:
        raise ProviderError("WEDDING_BOARD_TIMEOUT 必须是大于 0 的秒数。", CONFIG_ERROR)
    return value


def _generic_base_url(value: str) -> str:
    try:
        parts = urlsplit(value)
        port = parts.port
    except ValueError:
        raise ProviderError("WEDDING_BOARD_BASE_URL 格式无效。", CONFIG_ERROR) from None
    local = parts.hostname in {"localhost", "127.0.0.1", "::1"}
    scheme_ok = parts.scheme == "https" or (parts.scheme == "http" and local)
    if not scheme_ok or not parts.hostname or parts.username is not None or port == 0 or any(
        character in "?#\\" or character.isspace() or ord(character) < 32 for character in value
    ):
        raise ProviderError(
            "WEDDING_BOARD_BASE_URL 须为无凭证、查询参数或片段的 HTTPS 地址。"
            "本机回环地址也支持 HTTP。",
            CONFIG_ERROR,
        )
    return value.rstrip("/")


def _generic_sizes() -> tuple[tuple[int, int], ...]:
    value = _env("WEDDING_BOARD_GENERIC_SIZES") or "1024x1536"
    sizes = []
    for item in value.split(","):
        match = re.fullmatch(r"([1-9][0-9]{0,4})x([1-9][0-9]{0,4})", item.strip().lower())
        if not match or int(match[1]) >= int(match[2]):
            raise ProviderError(
                "WEDDING_BOARD_GENERIC_SIZES 须为逗号分隔的竖版像素尺寸，例如 1024x1536,1536x2048。",
                CONFIG_ERROR,
            )
        sizes.append((int(match[1]), int(match[2])))
    return tuple(sizes)


def resolve_config(
    provider: str | None, model: str | None, *, dry_run: bool
) -> ProviderConfig:
    name = provider or _env("WEDDING_BOARD_PROVIDER")
    if name:
        name = _provider_name(name)
    else:
        name = configured_provider()
        # A command-line model can complete a generic configuration.
        if not name and model and _key("generic") and _env("WEDDING_BOARD_BASE_URL"):
            name = "generic"
        if not name and dry_run:
            name = "openai"
        if not name:
            raise ProviderError(
                "未找到已配置的生图后端。请设置服务密钥，或使用 --dry-run 检查参数。",
                CONFIG_ERROR,
            )

    key = _key(name)
    if not dry_run and not key:
        key_names = " 或 ".join(_KEY_NAMES[name])
        raise ProviderError(f"所选后端缺少 API 密钥。请设置 {key_names}。", CONFIG_ERROR)
    if not dry_run and key and (not key.isascii() or any(ord(c) < 33 or ord(c) > 126 for c in key)):
        raise ProviderError("API 密钥包含无效字符。请检查环境变量的值。", CONFIG_ERROR)

    resolved_model = (model or "").strip() or _env("WEDDING_BOARD_MODEL")
    timeout = _timeout()
    if name != "generic":
        backend = _PROVIDERS[name]
        return ProviderConfig(name, resolved_model or backend.DEFAULT_MODEL, key, backend.BASE_URL, timeout)

    base_url = _env("WEDDING_BOARD_BASE_URL")
    if not dry_run and not (resolved_model and base_url):
        raise ProviderError("generic 需要 WEDDING_BOARD_BASE_URL 和模型名称。", CONFIG_ERROR)
    if resolved_model and any(ord(c) < 32 for c in resolved_model):
        raise ProviderError("网关模型名称含无效字符。", CONFIG_ERROR)
    image_field = _env("WEDDING_BOARD_GENERIC_IMAGE_FIELD") or "image"
    if image_field not in ("image", "image[]"):
        raise ProviderError("WEDDING_BOARD_GENERIC_IMAGE_FIELD 须为 image 或 image[]。", CONFIG_ERROR)
    send_quality = _env("WEDDING_BOARD_GENERIC_SEND_QUALITY") or "1"
    if send_quality not in ("0", "1"):
        raise ProviderError("WEDDING_BOARD_GENERIC_SEND_QUALITY 须为 0 或 1。", CONFIG_ERROR)
    return ProviderConfig(
        name,
        resolved_model or generic.DRY_RUN_MODEL,
        key,
        _generic_base_url(base_url or generic.DRY_RUN_BASE_URL),
        timeout,
        _generic_sizes(),
        image_field,
        send_quality == "1",
    )


def plan_request(config: ProviderConfig, request: ImageRequest) -> RequestPlan:
    if request.mime_type not in MIME_EXTENSIONS:
        raise ProviderError("参考图格式须为 PNG、JPEG 或 WebP。", INPUT_ERROR)
    if not request.prompt.strip():
        raise ProviderError("提示词为空。请先生成完整的提示词文件。", INPUT_ERROR)
    if not 0 < request.width < request.height:
        raise ProviderError("尺寸须为正数像素的竖版宽×高。", SIZE_ERROR)
    if request.quality not in ("auto", "low", "medium", "high"):
        raise ProviderError("质量须为 auto、low、medium 或 high。", INPUT_ERROR)
    return _PROVIDERS[_provider_name(config.name)].plan(config, request)


def generate(config: ProviderConfig, request: ImageRequest, plan: RequestPlan) -> bytes:
    if not config.api_key:
        raise ProviderError("所选后端缺少 API 密钥，无法发起生图请求。", CONFIG_ERROR)
    return _PROVIDERS[_provider_name(config.name)].generate(config, request, plan)
