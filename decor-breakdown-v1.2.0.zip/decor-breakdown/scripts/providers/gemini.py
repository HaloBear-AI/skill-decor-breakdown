"""Gemini Developer API native image generation via generateContent."""

import base64
from urllib.request import Request

from ._shared import (
    CONFIG_ERROR,
    INPUT_ERROR,
    MIME_EXTENSIONS,
    MODERATION_ERROR,
    RESPONSE_ERROR,
    ImageRequest,
    ProviderConfig,
    ProviderError,
    RequestPlan,
    decode_image,
    distance_to_request,
    encode_json,
    fetch_json,
    list_or_empty,
    make_plan,
    object_or_empty,
    reference_bytes,
    reference_size,
)


DEFAULT_MODEL = "gemini-3-pro-image"
BASE_URL = "https://generativelanguage.googleapis.com/v1beta"
_MAX_INLINE_REQUEST = 20_000_000
_MAX_REFERENCE = _MAX_INLINE_REQUEST * 3 // 4
_PRO_SIZES = {"2:3": (848, 1264), "3:4": (896, 1200), "4:5": (928, 1152), "9:16": (768, 1376)}
_FLASH_SIZES = {**_PRO_SIZES, "1:4": (512, 2048), "1:8": (384, 3072)}
_MODEL_SIZES = {DEFAULT_MODEL: _PRO_SIZES, "gemini-3.1-flash-image": _FLASH_SIZES}
_LEVELS = (("1K", 1), ("2K", 2), ("4K", 4))
_BLOCKED_REASONS = {
    "SAFETY", "RECITATION", "BLOCKLIST", "PROHIBITED_CONTENT", "SPII",
    "IMAGE_SAFETY", "IMAGE_PROHIBITED_CONTENT", "IMAGE_RECITATION", "MODEL_ARMOR",
    "ESCALATION", "PUP_LIMITED_DISABLED",
}


def _payload(request: ImageRequest, plan: RequestPlan, encoded_image: str) -> dict:
    return {
        "contents": [{
            "role": "user",
            "parts": [
                {"text": request.prompt},
                {"inlineData": {"mimeType": request.mime_type, "data": encoded_image}},
            ],
        }],
        **plan.parameters,
    }


def _payload_size_error() -> ProviderError:
    return ProviderError(
        "Gemini 内联请求编码后须小于 20 MB。请减小参考图文件，再重新生成。",
        INPUT_ERROR,
    )


def plan(config: ProviderConfig, request: ImageRequest) -> RequestPlan:
    native_sizes = _MODEL_SIZES.get(config.model)
    if not native_sizes:
        raise ProviderError(
            "Gemini 适配器尚未收录该型号的编辑参数。请选择 gemini-3-pro-image 或 gemini-3.1-flash-image。",
            CONFIG_ERROR,
        )

    # Prefer the nearest documented aspect ratio, then the nearest resolution in that ratio.
    requested_ratio = request.width / request.height
    ratio = min(native_sizes, key=lambda value: abs(
        int(value.split(":")[0]) / int(value.split(":")[1]) - requested_ratio
    ))
    base_width, base_height = native_sizes[ratio]
    scales = _LEVELS if config.model == DEFAULT_MODEL else (("512", 0.5), *_LEVELS)
    options = [(label, (int(base_width * scale), int(base_height * scale))) for label, scale in scales]
    image_size, size = min(options, key=lambda option: distance_to_request(option[1], request))
    parameters = {
        "generationConfig": {
            "responseModalities": ["IMAGE"],
            "imageConfig": {"aspectRatio": ratio, "imageSize": image_size},
        },
    }
    request_plan = make_plan(
        request,
        size,
        parameters,
        "Gemini 通过 imageSize 控制原生分辨率。此后端的清晰度档由 --size 选择。",
    )
    binary_size = reference_size(request, _MAX_REFERENCE)
    encoded_size = 4 * ((binary_size + 2) // 3)
    if len(encode_json(_payload(request, request_plan, ""))) + encoded_size >= _MAX_INLINE_REQUEST:
        raise _payload_size_error()
    return request_plan


def generate(config: ProviderConfig, request: ImageRequest, plan: RequestPlan) -> bytes:
    reference = reference_bytes(request, _MAX_REFERENCE)
    encoded_image = base64.b64encode(reference).decode("ascii")
    body = encode_json(_payload(request, plan, encoded_image))
    if len(body) >= _MAX_INLINE_REQUEST:
        raise _payload_size_error()
    http_request = Request(
        f"{config.base_url}/models/{config.model}:generateContent",
        data=body,
        headers={"x-goog-api-key": config.api_key, "Content-Type": "application/json"},
        method="POST",
    )
    payload = fetch_json(http_request, config.timeout)
    feedback = object_or_empty(payload.get("promptFeedback"))
    if feedback.get("blockReason") not in (None, "", "BLOCK_REASON_UNSPECIFIED"):
        raise ProviderError("Gemini 因内容审核拒绝了提示词或参考图。", MODERATION_ERROR)

    blocked = False
    for raw_candidate in list_or_empty(payload.get("candidates")):
        candidate = object_or_empty(raw_candidate)
        reason = candidate.get("finishReason")
        if isinstance(reason, str) and reason in _BLOCKED_REASONS:
            blocked = True
            continue
        content = object_or_empty(candidate.get("content"))
        for raw_part in list_or_empty(content.get("parts")):
            part = object_or_empty(raw_part)
            if part.get("thought") is True:
                continue
            inline = object_or_empty(part.get("inlineData"))
            mime = inline.get("mimeType")
            if isinstance(mime, str) and mime in MIME_EXTENSIONS:
                return decode_image(inline.get("data"))
    if blocked:
        raise ProviderError("Gemini 因内容审核停止了图像生成。", MODERATION_ERROR)
    raise ProviderError("Gemini 未返回最终图像。请检查模型是否支持图像输出。", RESPONSE_ERROR)
