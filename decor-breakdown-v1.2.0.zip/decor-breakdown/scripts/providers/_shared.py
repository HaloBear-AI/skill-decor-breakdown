"""Shared provider inputs, output decoding, and HTTP transport."""

import base64
import binascii
from dataclasses import dataclass, field
from http.client import HTTPException
import json
from pathlib import Path
from stat import S_ISREG
from urllib.error import HTTPError, URLError
from urllib.request import HTTPRedirectHandler, Request, build_opener
from uuid import uuid4


INPUT_ERROR = 2
CONFIG_ERROR = 3
AUTH_ERROR = 4
MODERATION_ERROR = 5
TIMEOUT_ERROR = 6
SIZE_ERROR = 7
RESPONSE_ERROR = 9
IO_ERROR = 10

MIME_EXTENSIONS = {"image/png": "png", "image/jpeg": "jpg", "image/webp": "webp"}
MAX_MULTIPART_REFERENCE = 50_000_000
MAX_IMAGE_BYTES = 80 * 1024 * 1024
MAX_BASE64_LENGTH = 4 * ((MAX_IMAGE_BYTES + 2) // 3)
MAX_JSON_BYTES = MAX_BASE64_LENGTH + 1024 * 1024


class ProviderError(Exception):
    def __init__(self, message: str, exit_code: int):
        super().__init__(message)
        self.exit_code = exit_code


@dataclass(frozen=True)
class ProviderConfig:
    name: str
    model: str
    api_key: str | None = field(repr=False)
    base_url: str
    timeout: float
    generic_sizes: tuple[tuple[int, int], ...] = ((1024, 1536),)
    generic_image_field: str = "image"
    generic_send_quality: bool = True


@dataclass(frozen=True)
class ImageRequest:
    reference: Path
    mime_type: str
    prompt: str
    width: int
    height: int
    quality: str


@dataclass(frozen=True)
class RequestPlan:
    parameters: dict
    width: int
    height: int
    notices: tuple[str, ...] = ()


def make_plan(
    request: ImageRequest, size: tuple[int, int], parameters: dict, *notices: str
) -> RequestPlan:
    width, height = size
    if size != (request.width, request.height):
        notices += (
            f"目标尺寸为 {request.width}×{request.height}，后端将请求 {width}×{height}。",
        )
    return RequestPlan(parameters, width, height, notices)


def distance_to_request(size: tuple[int, int], request: ImageRequest) -> float:
    width, height = size
    return ((width - request.width) / request.width) ** 2 + (
        (height - request.height) / request.height
    ) ** 2


def reference_size(request: ImageRequest, limit: int) -> int:
    try:
        info = request.reference.stat()
    except OSError:
        raise ProviderError("无法读取参考图。请检查文件路径与权限。", IO_ERROR) from None
    if not S_ISREG(info.st_mode) or not info.st_size:
        raise ProviderError("参考图必须是非空的图像文件。", INPUT_ERROR)
    if info.st_size >= limit:
        raise ProviderError(
            f"参考图超过该请求的体积限制（须小于 {limit / 1_000_000:g} MB）。请缩小文件后重试。",
            INPUT_ERROR,
        )
    return info.st_size


def image_mime(data: bytes) -> str | None:
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png"
    if data.startswith(b"\xff\xd8\xff"):
        return "image/jpeg"
    if data.startswith(b"RIFF") and data[8:12] == b"WEBP":
        return "image/webp"
    return None


def reference_bytes(request: ImageRequest, limit: int) -> bytes:
    reference_size(request, limit)
    try:
        with request.reference.open("rb") as reference:
            data = reference.read(limit)
    except OSError:
        raise ProviderError("无法读取参考图。请检查文件路径与权限。", IO_ERROR) from None
    if len(data) >= limit or image_mime(data) != request.mime_type:
        raise ProviderError("参考图已变化或格式无效。请重新选择 PNG、JPEG 或 WebP。", INPUT_ERROR)
    return data


def encode_json(payload: dict) -> bytes:
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def object_or_empty(value: object) -> dict:
    return value if isinstance(value, dict) else {}


def list_or_empty(value: object) -> list:
    return value if isinstance(value, list) else []


def validate_image_bytes(data: bytes) -> bytes:
    if len(data) > MAX_IMAGE_BYTES:
        raise ProviderError("返回的图像文件超过大小上限。", RESPONSE_ERROR)
    if not image_mime(data):
        raise ProviderError("服务返回的数据不是 PNG、JPEG 或 WebP 图像。", RESPONSE_ERROR)
    return data


def decode_image(value: object) -> bytes:
    if not isinstance(value, str) or not value or len(value) > MAX_BASE64_LENGTH:
        raise ProviderError("服务返回的图像数据缺失或超过大小上限。", RESPONSE_ERROR)
    try:
        data = base64.b64decode(value, validate=True)
    except (binascii.Error, ValueError):
        raise ProviderError("服务返回的图像编码无效。", RESPONSE_ERROR) from None
    return validate_image_bytes(data)


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        # Keep API credentials and request bytes at the configured origin.
        return None


def _http_error(status: int, payload: dict) -> ProviderError:
    error = object_or_empty(payload.get("error"))
    codes = [error.get(key) for key in ("code", "type", "status")]
    codes.extend(object_or_empty(detail).get("reason") for detail in list_or_empty(error.get("details")))
    codes = {value.lower() for value in codes if isinstance(value, str)}
    message = error.get("message")
    message = message.lower() if isinstance(message, str) else ""

    # Providers may echo inputs and credentials. Inspect values only for classification.
    if codes & {
        "moderation_blocked", "content_policy_violation", "safety_violations",
        "prohibited_content", "image_safety", "image_prohibited_content",
    } or any(term in message for term in ("safety system", "content policy", "moderation")):
        return ProviderError("生图服务因内容审核拒绝生成。", MODERATION_ERROR)
    if status in (401, 403) or codes & {
        "invalid_api_key", "api_key_invalid", "api_key_expired", "api_key_service_blocked",
        "api_key_ip_address_blocked", "unauthenticated", "permission_denied",
    }:
        return ProviderError("生图服务鉴权失败。请检查 API 密钥、项目权限与模型权限。", AUTH_ERROR)
    if status in (408, 504) or "deadline_exceeded" in codes:
        return ProviderError("生图请求超时。可适当调高 WEDDING_BOARD_TIMEOUT 再试。", TIMEOUT_ERROR)
    if status in (400, 422) and (
        error.get("param") in ("size", "imageSize", "aspectRatio")
        or codes & {"invalid_size", "unsupported_size", "invalid_image_size"}
        or any(term in message for term in ("aspect ratio", "imagesize", "image size", "resolution"))
    ):
        return ProviderError("生图服务拒绝该尺寸。请调整 --size 或检查网关的尺寸列表。", SIZE_ERROR)
    if status == 413:
        return ProviderError("生图服务拒绝了过大的请求。请缩小参考图后重试。", INPUT_ERROR)
    if status == 429:
        return ProviderError("生图服务达到配额或频率限制（HTTP 429）。请检查账户配额。", RESPONSE_ERROR)
    if status == 404:
        return ProviderError("找不到生图接口或模型（HTTP 404）。请检查模型名称和服务地址。", RESPONSE_ERROR)
    if 300 <= status < 400:
        return ProviderError("服务返回重定向。请配置实际的接口或使用直链图像响应。", RESPONSE_ERROR)
    return ProviderError(f"生图服务请求失败（HTTP {status}）。请检查服务配置与状态。", RESPONSE_ERROR)


def fetch(request: Request, timeout: float, limit: int) -> bytes:
    try:
        with build_opener(_NoRedirect).open(request, timeout=timeout) as response:
            data = response.read(limit + 1)
    except HTTPError as error:
        with error:
            try:
                payload = object_or_empty(json.loads(error.read(64 * 1024)))
            except (UnicodeError, ValueError, OSError, HTTPException, RecursionError):
                payload = {}
        raise _http_error(error.code, payload) from None
    except TimeoutError:
        raise _http_error(408, {}) from None
    except URLError as error:
        if isinstance(error.reason, TimeoutError):
            raise _http_error(408, {}) from None
        raise ProviderError("无法连接生图服务。请检查网络与服务地址。", RESPONSE_ERROR) from None
    except (OSError, HTTPException, ValueError):
        raise ProviderError("生图服务连接中断或地址无效。请检查服务连接。", RESPONSE_ERROR) from None
    if len(data) > limit:
        raise ProviderError("生图服务的响应数据量超过上限。", RESPONSE_ERROR)
    return data


def fetch_json(request: Request, timeout: float) -> dict:
    try:
        payload = json.loads(fetch(request, timeout, MAX_JSON_BYTES))
    except (UnicodeError, ValueError, RecursionError):
        raise ProviderError("生图服务返回了无法解析的 JSON 响应。", RESPONSE_ERROR) from None
    if not isinstance(payload, dict):
        raise ProviderError("生图服务返回的 JSON 结构无效。", RESPONSE_ERROR)
    if "error" in payload:
        error = object_or_empty(payload["error"])
        code = error.get("code")
        error_status = code if isinstance(code, int) and 400 <= code < 600 else 400
        raise _http_error(error_status, payload)
    return payload


def post_image_edit(
    config: ProviderConfig,
    request: ImageRequest,
    plan: RequestPlan,
    image_field: str,
) -> dict:
    reference = reference_bytes(request, MAX_MULTIPART_REFERENCE)
    boundary = uuid4().hex
    start = f"--{boundary}\r\n".encode("ascii")
    fields = {**plan.parameters, "prompt": request.prompt}
    parts = []
    for field_name, value in fields.items():
        header = f'Content-Disposition: form-data; name="{field_name}"\r\n\r\n'
        parts.extend((start, header.encode("ascii"), str(value).encode("utf-8"), b"\r\n"))
    extension = MIME_EXTENSIONS[request.mime_type]
    file_header = (
        f'Content-Disposition: form-data; name="{image_field}"; filename="reference.{extension}"\r\n'
        f"Content-Type: {request.mime_type}\r\n\r\n"
    )
    parts.extend((start, file_header.encode("ascii"), reference, b"\r\n"))
    parts.append(f"--{boundary}--\r\n".encode("ascii"))
    endpoint = config.base_url.rstrip("/")
    if not endpoint.endswith("/images/edits"):
        endpoint += "/images/edits"
    http_request = Request(
        endpoint,
        data=b"".join(parts),
        headers={
            "Authorization": f"Bearer {config.api_key}",
            "Content-Type": f"multipart/form-data; boundary={boundary}",
            "Accept": "application/json",
        },
        method="POST",
    )
    response = fetch_json(http_request, config.timeout)
    images = list_or_empty(response.get("data"))
    if not images or not isinstance(images[0], dict):
        raise ProviderError("生图服务未返回图像。请检查模型是否支持参考图编辑。", RESPONSE_ERROR)
    return images[0]
