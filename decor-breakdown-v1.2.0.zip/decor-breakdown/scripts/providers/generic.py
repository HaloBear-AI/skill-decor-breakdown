"""OpenAI-compatible multipart Image Edits gateway."""

import ipaddress
from urllib.parse import urlsplit
from urllib.request import Request

from ._shared import (
    MAX_IMAGE_BYTES,
    MAX_MULTIPART_REFERENCE,
    RESPONSE_ERROR,
    ImageRequest,
    ProviderConfig,
    ProviderError,
    RequestPlan,
    decode_image,
    distance_to_request,
    fetch,
    make_plan,
    post_image_edit,
    reference_size,
    validate_image_bytes,
)


DRY_RUN_BASE_URL = "https://example.invalid/v1"
DRY_RUN_MODEL = "gateway-model"


def plan(config: ProviderConfig, request: ImageRequest) -> RequestPlan:
    reference_size(request, MAX_MULTIPART_REFERENCE)
    size = min(config.generic_sizes, key=lambda value: distance_to_request(value, request))
    fields = {"model": config.model, "size": f"{size[0]}x{size[1]}"}
    notices = []
    if config.generic_send_quality:
        fields["quality"] = request.quality
    else:
        notices.append("generic 未启用 quality 参数，网关使用自身的质量默认设置。")
    if config.base_url == DRY_RUN_BASE_URL or config.model == DRY_RUN_MODEL:
        notices.append("缺失的 generic 地址或模型使用 dry-run 占位值。")
    return make_plan(request, size, fields, *notices)


def _allowed_result_url(url: str) -> bool:
    try:
        parts = urlsplit(url)
        port = parts.port
    except ValueError:
        return False
    hostname = parts.hostname
    if parts.scheme != "https" or not hostname or parts.username is not None or port == 0:
        return False
    if any(c.isspace() or ord(c) < 32 or c == "\\" for c in url):
        return False
    try:
        return ipaddress.ip_address(hostname).is_global
    except ValueError:
        return "." in hostname.rstrip(".") and not hostname.rstrip(".").endswith(".localhost")


def generate(config: ProviderConfig, request: ImageRequest, plan: RequestPlan) -> bytes:
    image = post_image_edit(config, request, plan, config.generic_image_field)
    if image.get("b64_json"):
        return decode_image(image["b64_json"])
    url = image.get("url")
    if not isinstance(url, str) or not _allowed_result_url(url):
        raise ProviderError(
            "网关未返回可用的 b64_json 或 HTTPS 图像直链。请检查网关的图像编辑接口。",
            RESPONSE_ERROR,
        )
    # Result URLs are typically signed CDN links. Send only an unauthenticated GET.
    get = Request(url, headers={"Accept": "image/png,image/jpeg,image/webp"}, method="GET")
    return validate_image_bytes(fetch(get, config.timeout, MAX_IMAGE_BYTES))
