"""OpenAI Image API reference-image editing."""

from ._shared import (
    CONFIG_ERROR,
    INPUT_ERROR,
    MAX_MULTIPART_REFERENCE,
    ImageRequest,
    ProviderConfig,
    ProviderError,
    RequestPlan,
    decode_image,
    distance_to_request,
    make_plan,
    post_image_edit,
    reference_size,
)


DEFAULT_MODEL = "gpt-image-2.6-sunburst"
BASE_URL = "https://api.openai.com/v1"
_CUSTOM_SIZE_MODELS = {
    "gpt-image-2.6-sunburst",
    "gpt-image-2.6-flare",
    "gpt-image-2.5-sunburst",
    "gpt-image-2.5-sunburst-2026-09-08",
    "gpt-image-2.5-flare",
    "gpt-image-2.5-flare-2026-09-08",
    "gpt-image-2",
    "gpt-image-2-2026-04-21",
}
_STEP = 16
_MAX_EDGE = 3840
_MIN_PIXELS = 655_360
_MAX_PIXELS = 8_294_400


def _supports_size(width: int, height: int) -> bool:
    return (
        width % _STEP == height % _STEP == 0
        and height <= _MAX_EDGE
        and height <= width * 3
        and _MIN_PIXELS <= width * height <= _MAX_PIXELS
    )


def _nearest_size(request: ImageRequest) -> tuple[int, int]:
    """Find the valid portrait size with the smallest relative change to its two edges."""
    target_height_steps = round(request.height / _STEP)
    sizes = []
    for width in range(_STEP, _MAX_EDGE, _STEP):
        step_pixels = width * _STEP
        min_steps = max(width // _STEP + 1, (_MIN_PIXELS + step_pixels - 1) // step_pixels)
        max_steps = min(_MAX_EDGE // _STEP, width * 3 // _STEP, _MAX_PIXELS // step_pixels)
        if min_steps <= max_steps:
            height_steps = min(max_steps, max(min_steps, target_height_steps))
            sizes.append((width, height_steps * _STEP))
    return min(sizes, key=lambda size: distance_to_request(size, request))


def plan(config: ProviderConfig, request: ImageRequest) -> RequestPlan:
    reference_size(request, MAX_MULTIPART_REFERENCE)
    if len(request.prompt) > 32_000:
        raise ProviderError("OpenAI 图像编辑的提示词最多支持 32,000 个字符。", INPUT_ERROR)

    fields = {"model": config.model, "quality": request.quality, "output_format": "png"}
    if config.model in _CUSTOM_SIZE_MODELS:
        size = (request.width, request.height)
        if not _supports_size(*size):
            size = _nearest_size(request)
    elif config.model == "gpt-image-1.5":
        size = (1024, 1536)
        fields["input_fidelity"] = "high"
    else:
        raise ProviderError(
            "OpenAI 适配器尚未收录该型号的编辑参数。可使用 gpt-image-2.6-sunburst "
            "或参照 provider-notes.md 选择已支持型号。",
            CONFIG_ERROR,
        )
    fields["size"] = f"{size[0]}x{size[1]}"
    return make_plan(request, size, fields)


def generate(config: ProviderConfig, request: ImageRequest, plan: RequestPlan) -> bytes:
    image = post_image_edit(config, request, plan, "image[]")
    return decode_image(image.get("b64_json"))
