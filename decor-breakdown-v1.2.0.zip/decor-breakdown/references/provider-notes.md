# 生图后端与接口参数

三种适配器都把同一张 PNG、JPEG 或 WebP 参考图与提示词传给参考图编辑接口，HTTP 调用使用 Python 标准库。配置通过环境变量读取。参考图和提示词会在实际生成时送交所选服务，`--dry-run` 只在本地检查输入并显示请求参数。

| 后端 | 默认模型 | 密钥环境变量 | 目标为 1536×2048 时的原生请求 |
| --- | --- | --- | --- |
| `openai` | `gpt-image-2.6-sunburst` | `OPENAI_API_KEY` | `size=1536x2048` |
| `gemini` | `gemini-3-pro-image` | `GEMINI_API_KEY`，其次 `GOOGLE_API_KEY` | `aspectRatio=3:4`，`imageSize=2K`，原生 1792×2400 |
| `generic` | 由网关配置提供 | `WEDDING_BOARD_API_KEY` | 默认 1024×1536，可配置网关支持的尺寸 |

## OpenAI

- 使用 `POST https://api.openai.com/v1/images/edits`。以 multipart 的 `image[]` 传一张参考图，并传 `model`、`prompt`、`size`、`quality` 和 `output_format=png`。参考图须小于 50 MB，提示词最多 32,000 个字符。响应为 `data[0].b64_json`。 [编辑接口](https://developers.openai.com/api/reference/resources/images/methods/edit) · [文件规格](https://developers.openai.com/api/reference/python/resources/images/methods/edit)
- Sunburst 默认用于细节丰富且版式复杂的展板。也可选 `gpt-image-2.6-flare`、`gpt-image-2.5-sunburst`、`gpt-image-2.5-flare`、文档列出的上述 2.5 系列快照 `-2026-09-08`，或 `gpt-image-2` 及快照 `gpt-image-2-2026-04-21`。这些适配的型号以官方编辑接口的图像输入处理为准，省略 `input_fidelity`。 [模型说明](https://developers.openai.com/api/docs/models/gpt-image-2.6-sunburst) · [图像提示指南](https://developers.openai.com/api/docs/guides/image-prompting)
- 宽和高必须为 16 的倍数，长边最多 3840 像素，长边与短边之比最多 3:1，总像素为 655,360 至 8,294,400。超出这些条件时按两边相对偏差选最近的受支持竖版。旧版 `gpt-image-1.5` 使用 1024×1536 和 `input_fidelity=high`，其计划停用日期是 2026-12-01。 [尺寸规则](https://developers.openai.com/api/docs/guides/image-generation) · [停用计划](https://developers.openai.com/api/docs/deprecations)

## Gemini

- 使用 `POST https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent`，以 `x-goog-api-key` 鉴权。请求正文在 `contents[].parts[]` 中传 `text` 与 `inlineData`，在 `generationConfig` 中设置 `responseModalities=["IMAGE"]` 和 `imageConfig`。从候选项的 `content.parts[].inlineData` 读取最终图像。 [GenerateContent 接口](https://aistudio.google.com/api-reference/generate-content/generate-content) · [请求与响应结构](https://aistudio.google.com/api-reference/generate-content)
- `gemini-3-pro-image` 用于复杂构图与文字，可改用 `gemini-3.1-flash-image`。先匹配最接近的原生竖版比例，再匹配像素大小。Pro 的 3:4 分辨率依次是 896×1200、1792×2400、3584×4800，对应 `1K`、`2K`、`4K`。用 `--size` 选择清晰度档位，`--quality` 未映射到该接口。 [Pro 模型](https://aistudio.google.com/docs/models/gemini-3-pro-image) · [官方分辨率表](https://aistudio.google.com/docs/image-generation#aspect-ratios-and-image-size)
- 内联请求的总大小须小于 20 MB，包含 Base64 编码后的图像、UTF-8 提示词及 JSON 字段。参考图接近 15 MB 时可先压缩再生成。 [内联图像规格](https://aistudio.google.com/docs/image-understanding#inline-image)

## OpenAI 兼容网关

- 配置 `WEDDING_BOARD_BASE_URL`（例如网关的 `https://gateway.example/v1`）、`WEDDING_BOARD_API_KEY` 和 `WEDDING_BOARD_MODEL`。网关须支持 multipart 的 `POST /images/edits` 及原始参考图输入，响应须包含 `data[0].b64_json` 或可直接下载的 `data[0].url` HTTPS 图像链接。
- `WEDDING_BOARD_GENERIC_SIZES` 填网关支持的竖版像素尺寸列表（例如 `1024x1536,1536x2048`）。默认按 1024×1536 请求，实跑以网关文档为准。适配器接受小于 50 MB 的单张参考图，服务端可能另有体积限制。
- 文件字段默认为 `image`，若网关要求数组字段则设置 `WEDDING_BOARD_GENERIC_IMAGE_FIELD=image[]`。若网关由模型固定质量且未支持 `quality`，设置 `WEDDING_BOARD_GENERIC_SEND_QUALITY=0`，其余场景按 OpenAI 兼容值传 `auto`、`low`、`medium` 或 `high`。

API 将对生成请求执行账户权限、配额和内容审核。省略后端时按配置检测 OpenAI、Gemini、generic，优先顺序同上。`WEDDING_BOARD_TIMEOUT` 以秒配置，默认 300。遇到鉴权、审核、尺寸或连接问题时，脚本会返回对应的中文提示与退出码。
